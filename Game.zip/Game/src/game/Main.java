package game;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.Timer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.Animation;
import javafx.animation.AnimationTimer;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.util.Duration;

/**
 * **************************************************
 * This is the main class for Trading Amongst Stars.
 *
 * @author Skylor Criqui
 * @date 3/21/2018
 *
 ****************************************************
 */
public class Main extends Application {

    // Java Variables
    private int k = 0, i = 0, z = 0;
    private List<Player> players = new ArrayList<>();
    private List<Planet> planets = new ArrayList<>();
    private List<String> planetNames = new ArrayList<>();
    private List<String> resources = new ArrayList<>();
    private String planetName;
    private boolean collision = false;
    private Random rnd = new Random();
    private static int interval;
    private static Timer timer;
    private String secs;

    // JavaFX Variables
    Stage stage = new Stage();
    Pane playfieldLayer;
    Pane scoreLayer;
    Image playerImage;
    Image planetImage;
    Text collisionText = new Text();
    Scene scene;
    Label time = new Label();
    Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1), ev -> {
        time.setText("Seconds Left: " + Integer.toString(setInterval()));

    }));

    // Object Variables
    TradeUI tradeui = new TradeUI();

    @Override
    public void start(Stage primaryStage) throws Exception {
        int delay = 1000;
        int period = 1000;
        interval = 180;

        // UI
        // Creates a group and adds the player, planets, and score to it
        Group root = new Group();
        playfieldLayer = new Pane();
        scoreLayer = new Pane();
        time.setTextFill(Color.WHITE);
        scoreLayer.getChildren().add(time);
        time.setText("Seconds Left: 180");
        root.getChildren().add(playfieldLayer);
        root.getChildren().add(scoreLayer);

        // Setting up Stage
        scene = new Scene(root, Settings.W, Settings.H, Color.BLACK);
        primaryStage.setTitle("Trading Amongst Stars");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();

        // Setting up Game
        loadGame();
        createScoreLayer();
        createPlayer();
        timer();
        AnimationTimer gameLoop = new AnimationTimer() {
            @Override
            public void handle(long now) {

                // Processes Player Input
                players.forEach(player -> player.processInput());
                // Spawns Planets
                try {
                    spawnPlanets(true);
                } catch (IOException ex) {
                    System.out.println("The file has not successful processed.");
                }

                // Processes any movement for the player
                players.forEach(player -> player.move());

                try {
                    // Checks if the player is colliding with any planet
                    checkCollisions();
                } catch (FileNotFoundException ex) {
                    System.out.println("The file does not exist or cannot be found.");
                }

                // Shows the player moving
                players.forEach(player -> player.updateUI());

                // If there is a collision, a Trade button is created
                // If the Trade button is pressed, the TradeUI window opens
                if (collision) {
                    Button btTrade = new Button("Trade?");
                    root.getChildren().add(btTrade);
                    btTrade.setLayoutX(Settings.W / 2);
                    btTrade.requestFocus();
                    btTrade.setOnMousePressed(e -> {
                        try {
                            openTradeUI(stage);
                        } catch (Exception ex) {
                            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    });
                }
                if (interval == 0) {
                    Scanner inF;
                    try {
                        inF = new Scanner(new File("data/player.txt"));
                        double score = 0;
                        while (inF.hasNextLine()) {
                            String resource = inF.nextLine();
                            if (resource.equalsIgnoreCase("Diamond")) {
                                score = score + 2;
                            }
                            if (resource.equalsIgnoreCase("Carbon")) {
                                score = score + 1;
                            }
                            if (resource.equalsIgnoreCase("Water")) {
                                score = score + 3;
                            }
                            if (resource.equalsIgnoreCase("Gold")) {
                                score = score + 1.5;
                            }
                            if (resource.equalsIgnoreCase("Oxygen")) {
                                score = score + 1.5;
                            }
                            if (resource.equalsIgnoreCase("Helium")) {
                                score = score + 1;
                            }
                            if (resource.equalsIgnoreCase("Energy")) {
                                score = score + 3;
                            }
                            if (resource.equalsIgnoreCase("Silver")) {
                                score = score + 2.5;
                            }
                            if (resource.equalsIgnoreCase("Mud")) {
                                score = score + 0.5;
                            }
                        }
                        inF.close();
                        Label lbScore = new Label("Your Score is: " + score);

                        lbScore.setLayoutX(Settings.W / 2);
                        lbScore.setLayoutY(Settings.H / 2);
                        lbScore.setTextFill(Color.WHITE);
                        lbScore.setScaleX(2);
                        lbScore.setScaleY(2);

                        scoreLayer.getChildren().add(lbScore);
                        this.stop();
                        timeline.stop();
                    } catch (FileNotFoundException ex) {
                        Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        };
        // Runs the AnimationTimer Loop
        gameLoop.start();
        primaryStage.setOnCloseRequest((WindowEvent event) -> {
            try (PrintWriter outF = new PrintWriter(new File("data/config.txt"))) {
                outF.println("500");
                outF.close();
            } catch (FileNotFoundException ex) {
                System.out.println("The file does not exist or cannot be found.");
            }
            try (PrintWriter outF = new PrintWriter(new File("data/player.txt"))) {
                outF.print("");
                outF.close();
            } catch (FileNotFoundException ex) {
                System.out.println("The file does not exist or cannot be found.");
            }
        });
    }

    private void loadGame() {
        playerImage = new Image(getClass().getResource("player.bmp").toExternalForm());
        planetImage = new Image(getClass().getResource("Planet.bmp").toExternalForm());
        planetNames.add("Wahear");
        planetNames.add("Poald");
        planetNames.add("Zerwad");
        planetNames.add("Ulaplea");
        planetNames.add("Opnagad");
        planetNames.add("Ezvit");
        planetNames.add("Seznut");
        planetNames.add("Voltag");
        planetNames.add("Kligosh");
        resources.add("Diamonds");
        resources.add("Carbon");
        resources.add("Water");
        resources.add("Gold");
        resources.add("Oxygen");
        resources.add("Helium");
        resources.add("Mud");
        resources.add("Energy");
        resources.add("Silver");
    }

    // Shows the players score
    private void createScoreLayer() {

    }

    private int setInterval() {
        if (interval == 0) {
            timer.cancel();
        }
        return --interval;
    }

    private void timer() {
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.play();
    }

    private void createPlayer() {
        // Creates Object Variable to accept input from the player
        Input input = new Input(scene);

        // Lets the game to accept input
        input.addListeners();

        // Player image
        Image image = playerImage;

        // Player starting position
        double x = Settings.W - image.getWidth();
        double y = Settings.H - image.getHeight();

        // cCreate Player Object
        Player player = new Player(playfieldLayer, image, x, y, 0, 0, 0, 0, 2, input);

        // Add player to players arraylist
        players.add(player);
    }

    private void spawnPlanets(boolean random) throws IOException {
        if (k > 8 || z > planetNames.size()) {
            return;
        }
        // Gets a name for the planet
        planetName = planetNames.get(z);

        // Planet Image
        Image image = planetImage;

        // X Coordinate: Picks a random double and makes sure the planet is
        // in the window
        // Y Coordinate: Places Planets on 75 pixel intervals
        double x = rnd.nextDouble() * (Settings.W - image.getWidth());
        double y = i;

        // Create the Planet Object and adds it to the arraylist
        Planet planet = new Planet(30, planetName, playfieldLayer, image, x, y, 0, 0, 0, 0);
        planets.add(planet);

        // Increase Intervals
        k++;
        z++;
        i += 75;
    }

    private void checkCollisions() throws FileNotFoundException {
        collision = false;

        // Goes through the Player ArrayList to see which player is
        // colliding. Goes through the Planet ArrayList to see which
        // planet is colliding. Returns the Planets name.
        players.forEach((Player player) -> {
            planets.stream().filter((planet) -> (player.collidesWith(planet))).map((planet) -> {
                collision = true;
                return planet;
            }).forEachOrdered((planet) -> {
                try (PrintWriter outF = new PrintWriter(new File("data/collision.txt"))) {
                    outF.println(planet.getName());
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
                }
            });
        });
    }

    private void openTradeUI(Stage stage) throws Exception {
        tradeui.start(stage);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
