package game;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;

/**
 *
 * @author Skylor Criqui
 */
public class Planet extends Entity{
    // Java Variables
    private String name;
    private String resource;
    private double balance;
    
    // Constructors
    public Planet(double balance, String name, Pane layer, Image image, double x, double y, double r, double dx, double dy, double dr) throws IOException {
        super(layer, image, x, y, r, dx, dy, dr);
        setName(name);
        setBalance(balance);
    }
    
    public String getName(){
        return this.name;
    }
    
    public void setName(String name){
        this.name = name;
    }
    
    public Double getBalance(){
        return this.balance;
    }
    
    public void setBalance(double balance){
        this.balance = balance;
    }
    
    public String getResource(){
        return this.resource;
    }
    
    public void setResource(String resource){
        this.resource = resource;
    }
    
}
