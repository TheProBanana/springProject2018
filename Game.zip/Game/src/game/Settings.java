package game;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Skylor Criqui
 */
public class Settings {
    static final int W = 1280;
    static final int H = 720;
    public static int PLANET_SPAWN_RANDOMNESS = 25;
}
