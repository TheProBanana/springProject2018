package game;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Skylor Criqui
 */
public class Trader {
    // Java Variables
    private String name;
    private double balance;
    private double resourcePrice;
    private List<String> resources = new ArrayList<>();
    
    // Constructors
    public Trader(){
        this.name = "Voltag";
        this.balance = 500;
    }
    
    public Trader(String name){
        setName(name);
    }
    
    // Reads file with same planet name.
    public void readFile() throws FileNotFoundException{
        Scanner inF = new Scanner(new File("data/" + name + ".txt"));
        String word = "";
        while(inF.hasNext()){
            if(inF.next().equals("Balance")){
                word = inF.next();
                this.balance = Double.parseDouble(word);
            } else if(inF.next().equals("Items")){
                word = inF.next();
                String[] words = word.split(",");
                for(int k = 1; k < words.length; k++){
                    resources.add(words[k]);
                }
            }
        }
    }
    
    public String getName(){
        return this.name;
    }
    
    public void setName(String name){
        this.name = name;
    }
    
    public double getBalance(){
        return this.balance;
    }
    
    public void setBalance(double balance){
        this.balance = balance;
    }
}
