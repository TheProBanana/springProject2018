package game;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * **************************************************
 * This is the main class for Trading Amongst Stars.
 *
 * @author Skylor Criqui
 * @date 3/21/2018
 *
 ****************************************************
 */
public class Main extends Application {

    // Java Variables
    int k = 0, i = 0, z = 0;
    List<Player> players = new ArrayList<>();
    List<Planet> planets = new ArrayList<>();
    List<String> planetNames = new ArrayList<>();
    List<String> resources = new ArrayList<>();
    String planetName;
    boolean collision = false;
    Random rnd = new Random();

    // JavaFX Variables
    Stage stage = new Stage();
    Pane playfieldLayer;
    Pane scoreLayer;
    Image playerImage;
    Image planetImage;
    Text collisionText = new Text();
    Scene scene;

    // Object Variables
    TradeUI tradeui = new TradeUI();

    @Override
    public void start(Stage primaryStage) throws Exception {
        // UI

        // Creates a group and adds the player, planets, and score to it
        Group root = new Group();
        playfieldLayer = new Pane();
        scoreLayer = new Pane();
        root.getChildren().add(playfieldLayer);
        root.getChildren().add(scoreLayer);

        // Setting up Stage
        scene = new Scene(root, Settings.W, Settings.H, Color.BLACK);
        primaryStage.setTitle("Trading Amongst Stars");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();

        // Setting up Game
        loadGame();
        createScoreLayer();
        createPlayer();
        AnimationTimer gameLoop = new AnimationTimer() {
            @Override
            public void handle(long now) {

                // Processes Player Input
                players.forEach(player -> player.processInput());
                // Spawns Planets
                try {
                    spawnPlanets(true);
                } catch (IOException ex) {
                    System.out.println("The file has not successful processed.");
                }

                // Processes any movement for the player
                players.forEach(player -> player.move());

                try {
                    // Checks if the player is colliding with any planet
                    checkCollisions();
                } catch (FileNotFoundException ex) {
                    System.out.println("The file does not exist or cannot be found.");
                }

                // Shows the player moving
                players.forEach(player -> player.updateUI());

                // If there is a collision, a Trade button is created
                // If the Trade button is pressed, the TradeUI window opens
                if (collision) {
                    Button btTrade = new Button("Trade?");
                    root.getChildren().add(btTrade);
                    btTrade.requestFocus();
                    btTrade.setOnMousePressed(e -> {
                        try {
                            openTradeUI(stage);
                        } catch (Exception ex) {
                            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    });
                }
            }
        };
        // Runs the AnimationTimer Loop
        gameLoop.start();
        primaryStage.setOnCloseRequest((WindowEvent event) -> {
            try (PrintWriter outF = new PrintWriter(new File("data/config.txt"))) {
                outF.println("500");
            } catch (FileNotFoundException ex) {
                System.out.println("The file does not exist or cannot be found.");
            }
            try (PrintWriter outF = new PrintWriter(new File("data/player.txt"))) {
                outF.print("");
            } catch (FileNotFoundException ex) {
                System.out.println("The file does not exist or cannot be found.");
            }
        });
    }

    private void loadGame() {
        playerImage = new Image(getClass().getResource("player.bmp").toExternalForm());
        planetImage = new Image(getClass().getResource("Planet.bmp").toExternalForm());
        planetNames.add("Wahear");
        planetNames.add("Poald");
        planetNames.add("Zerwad");
        planetNames.add("Ulaplea");
        planetNames.add("Opnagad");
        planetNames.add("Ezvit");
        planetNames.add("Seznut");
        planetNames.add("Voltag");
        planetNames.add("Kligosh");
        resources.add("Diamonds");
        resources.add("Carbon");
        resources.add("Water");
        resources.add("Gold");
        resources.add("Oxygen");
        resources.add("Helium");
        resources.add("Mud");
        resources.add("Nuclear Energy");
        resources.add("Silver");
    }

    // Shows the players score
    private void createScoreLayer() {

    }

    private void createPlayer() {
        // Creates Object Variable to accept input from the player
        Input input = new Input(scene);

        // Lets the game to accept input
        input.addListeners();

        // Player image
        Image image = playerImage;

        // Player starting position
        double x = Settings.W - image.getWidth();
        double y = Settings.H - image.getHeight();

        // cCreate Player Object
        Player player = new Player(playfieldLayer, image, x, y, 0, 0, 0, 0, 2, input);

        // Add player to players arraylist
        players.add(player);
    }

    private void spawnPlanets(boolean random) throws IOException {
        if (k > 8 || z > planetNames.size()) {
            return;
        }
        // Gets a name for the planet
        planetName = planetNames.get(z);

        // Planet Image
        Image image = planetImage;

        // X Coordinate: Picks a random double and makes sure the planet is
        // in the window
        // Y Coordinate: Places Planets on 75 pixel intervals
        double x = rnd.nextDouble() * (Settings.W - image.getWidth());
        double y = i;

        // Create the Planet Object and adds it to the arraylist
        Planet planet = new Planet(30, planetName, playfieldLayer, image, x, y, 0, 0, 0, 0);
        planets.add(planet);

        // Increase Intervals
        k++;
        z++;
        i += 75;
    }

    private void checkCollisions() throws FileNotFoundException {
        collision = false;

        // Goes through the Player ArrayList to see which player is
        // colliding. Goes through the Planet ArrayList to see which
        // planet is colliding. Returns the Planets name.
        for (Player player : players) {
            for (Planet planet : planets) {
                if (player.collidesWith(planet)) {
                    collision = true;
                    try (PrintWriter outF = new PrintWriter(new File("data/collision.txt"))) {
                        outF.println(planet.getName());
                    }
                }
            }
        }
    }

    private void openTradeUI(Stage stage) throws Exception {
        tradeui.start(stage);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
