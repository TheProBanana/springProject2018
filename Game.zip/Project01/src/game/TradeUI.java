package game;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 *
 * @author Skylor Criqui
 */
public class TradeUI extends Application {

    // Java Variables
    private Scanner inF;
    private String player;
    private String planetName;
    private String yourBalance;
    private String theirBalance;
    private String resource;
    private double resourcePrice;
    private Random rnd = new Random();

    // JavaFX variables
    private Label lbPlanetName = new Label(planetName);
    private Label lbYourBalance = new Label("Your Balance:");
    private Label lbResource = new Label("Resource:");
    private Label lbResourcePrice = new Label("Price:");
    private Label lbTheirBalance = new Label("Their Balance:");
    private TextField tfYourBalance = new TextField(yourBalance);
    private TextField tfResource = new TextField(resource);
    private TextField tfResourcePrice = new TextField();
    private TextField tfTheirBalance = new TextField(theirBalance);
    private Button btBuy = new Button("Buy");
    private Button btSell = new Button("Sell");

    @Override
    public void start(Stage primaryStage) throws Exception {
        // UI
        GridPane pane = new GridPane();
        pane.setHgap(5);
        pane.setVgap(5);

        // Gets all planet properties
        getPlanetProperties();

        // Reading in Your Balance from a text file
        getYourBalance();

        // Adding the labels, textfields, and buttons to the GridPane
        pane.add(lbPlanetName, 0, 0);
        pane.add(lbYourBalance, 0, 1);
        pane.add(tfYourBalance, 1, 1);
        pane.add(lbResource, 0, 2);
        pane.add(tfResource, 1, 2);
        pane.add(lbResourcePrice, 0, 3);
        pane.add(tfResourcePrice, 1, 3);
        pane.add(lbTheirBalance, 0, 4);
        pane.add(tfTheirBalance, 1, 4);
        pane.add(btBuy, 0, 5);
        pane.add(btSell, 1, 5);

        // Properties of the GridPane as well as the JavaFx variables
        pane.setAlignment(Pos.CENTER);
        pane.setHalignment(btBuy, HPos.CENTER);
        pane.setHalignment(btSell, HPos.CENTER);
        tfYourBalance.setEditable(false);
        tfResource.setEditable(false);
        tfResourcePrice.setEditable(false);
        tfTheirBalance.setEditable(false);

        // Events and methods
        // This event is triggered when the "Buy" button is clicked
        // When the button is clicked, it goes to the buy method
        btBuy.setOnAction(e -> {
            try {
                buy();
            } catch (FileNotFoundException ex) {
                System.out.println("The file does not exist or cannot be found.");
            } catch (IOException ex) {
                System.out.println("The file has not successful processed.");
            }
        });

        // This event is triggered when the "Sell" button is clicked
        // When the button is clicked, it goes to the sell method
        btSell.setOnAction(e -> {
            try {
                sell();
            } catch (FileNotFoundException ex) {
                System.out.println("The file does not exist or cannot be found.");
            }
        });

        // This event is triggered when the window is closed
        // When the window is closed, it updates your balance as well 
        // as the traders balance
        primaryStage.setOnCloseRequest((WindowEvent event) -> {
            try (PrintWriter outF = new PrintWriter(new File("data/config.txt"))) {
                outF.println(tfYourBalance.getText());
                outF.println(tfTheirBalance.getText());
            } catch (FileNotFoundException ex) {
                System.out.println("The file does not exist or cannot be found.");
            }
            try (PrintWriter outF = new PrintWriter(new File("data/" + planetName + ".txt"))) {
                outF.println("Balance," + tfTheirBalance.getText());
                outF.println("Resource," + tfResource.getText());
            } catch (FileNotFoundException ex) {
                System.out.println("The file does not exist or cannot be found.");
            }
        });

        // Setting up stage
        primaryStage.setTitle("TradeUI");
        primaryStage.setScene(new Scene(pane, 640, 480));
        primaryStage.show();
        inF.close();
    }

    private void getYourBalance() throws FileNotFoundException {
        inF = new Scanner(new File("data/config.txt"));
        this.yourBalance = Double.toString(inF.nextDouble());
        tfYourBalance.setText(yourBalance);
    }

    private void getPlanetProperties() throws FileNotFoundException {
        inF = new Scanner(new File("data/collision.txt"));
        this.planetName = inF.next();
        lbPlanetName.setText(planetName);

        // Reading in the planets balance and resource
        // from the specific planet's text file
        inF = new Scanner(new File("data/" + planetName + ".txt"));
        this.theirBalance = inF.nextLine();
        this.theirBalance = this.theirBalance.replace("Balance", "");
        this.theirBalance = this.theirBalance.replace(",", "");
        tfTheirBalance.setText(this.theirBalance);
        this.resource = inF.nextLine();
        this.resource = this.resource.replace("Resource,", "");
        tfResource.setText(this.resource);
        if (this.resource.equalsIgnoreCase("Diamond")) {
            this.resourcePrice = rnd.nextInt(2000) + 1;
        }
        if (this.resource.equalsIgnoreCase("Carbon")) {
            this.resourcePrice = rnd.nextInt(200) + 1;
        }
        if (this.resource.equalsIgnoreCase("Water")) {
            this.resourcePrice = rnd.nextInt(1000) + 1;
        }
        if (this.resource.equalsIgnoreCase("Gold")) {
            this.resourcePrice = rnd.nextInt(500) + 1;
        }
        if (this.resource.equalsIgnoreCase("Oxygen")) {
            this.resourcePrice = rnd.nextInt(800) + 1;
        }
        if (this.resource.equalsIgnoreCase("Helium")) {
            this.resourcePrice = rnd.nextInt(200) + 1;
        }
        if (this.resource.equalsIgnoreCase("Energy")) {
            this.resourcePrice = rnd.nextInt(5000) + 1;
        }
        if (this.resource.equalsIgnoreCase("Silver")) {
            this.resourcePrice = rnd.nextInt(700) + 1;
        }
        if (this.resource.equalsIgnoreCase("Mud")) {
            this.resourcePrice = rnd.nextInt(10) + 1;
        }
        tfResourcePrice.setText(Double.toString(this.resourcePrice));
    }

    // When you want to buy a resource, this method checks if you are able
    // to buy the resoure, if so , it will add the resource to your inventory
    private void buy() throws FileNotFoundException, IOException {
        try {
            // Takes your balance and turns it to a double
            tfYourBalance.requestFocus();
            double playerBalance = Double.parseDouble(tfYourBalance.getText());

            // Takes the item price and turns it to a double
            tfResourcePrice.requestFocus();
            double price = Double.parseDouble(tfResourcePrice.getText());

            // Takes the traders balance and turns it to a double
            tfTheirBalance.requestFocus();
            double traderBalance = Double.parseDouble(tfTheirBalance.getText());

            // Checks to see if you can buy the resource
            playerBalance = playerBalance - price;
            traderBalance = traderBalance + price;
            if (playerBalance >= 0) {
                // Turns your balance and the traders balance into doubles
                tfYourBalance.setText(Double.toString(playerBalance));
                tfTheirBalance.setText(Double.toString(traderBalance));

                // Adds the resource to your inventory
                try (PrintWriter outF = new PrintWriter(new BufferedWriter(new FileWriter("data/player.txt", true)))) {
                    outF.println(this.resource + "\n");
                    outF.close();
                }

                // If you do not have enough money, an alert will tell you
                // that you can not buy the resource
            } else {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("TradeUI");
                alert.setHeaderText("Error Alert");
                String s = "You do not have enough money to buy this item.";
                alert.setContentText(s);
                alert.show();
            }
        } catch (IllegalArgumentException ex) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("TradeUI");
            alert.setHeaderText("Error Alert");
            String s = "Hi";
            alert.setContentText(s);
            alert.show();
        }
    }

    // When you want to sell a resource, this method checks if the trader is 
    // able to buy the resoure, if so , it will add the resource to the
    // traders inventory
    private void sell() throws FileNotFoundException {
        try {
            inF = new Scanner(new File("data/player.txt"));
            // Takes your balance and turns it to a double
            tfYourBalance.requestFocus();
            double playerBalance = Double.parseDouble(tfYourBalance.getText());

            // Takes the item price and turns it to a double
            tfResourcePrice.requestFocus();
            double price = Double.parseDouble(tfResourcePrice.getText());

            // Takes the traders balance and turns it to a double
            tfTheirBalance.requestFocus();
            double traderBalance = Double.parseDouble(tfTheirBalance.getText());
            if (CheckWord(tfResource.getText(), new File("data/player.txt"))) {
                while (inF.hasNextLine()) {
                    String line = inF.nextLine();
                    if (line.equals(tfResource)) {
                        // Checks to see if you can sell the resource
                        playerBalance = playerBalance + price;
                        traderBalance = traderBalance - price;
                        if (traderBalance >= 0) {
                            // Turns your balance and the traders balance into doubles
                            tfYourBalance.setText(Double.toString(playerBalance));
                            tfTheirBalance.setText(Double.toString(traderBalance));

                            // Takes the item from your inventory
                            PrintWriter outF = new PrintWriter(new File("data/player.txt"));
                            line = line.replace(resource, "");
                            outF.print(line);
                            return;

                            // If the trader does not have enough money to buy the resource,
                            // an alert will show
                        } else {
                            Alert alert = new Alert(Alert.AlertType.INFORMATION);
                            alert.setTitle("TradeUI");
                            alert.setHeaderText("Error Alert");
                            String s = "The trader does not have enough money to buy this item.";
                            alert.setContentText(s);
                            alert.show();
                            return;
                        }
                    }
                }
            } else {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("TradeUI");
                alert.setHeaderText("Error Alert");
                String s = "You do not have any " + tfResource.getText() + " to sell.";
                alert.setContentText(s);
                alert.show();
                return;
            }
        } catch (IllegalArgumentException ex) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("TradeUI");
            alert.setHeaderText("Error Alert");
            String s = "Your input is invalid. Correct and resubmit.";
            alert.setContentText(s);
            alert.show();
            return;
        }
    }

    public boolean CheckWord(String theWord, File theFile) throws FileNotFoundException {
        return (new Scanner(theFile).nextLine()).equalsIgnoreCase(theWord);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
